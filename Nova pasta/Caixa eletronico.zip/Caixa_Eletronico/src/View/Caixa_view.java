package View;
import java.util.Scanner;

public class Caixa_view {
	public Scanner scanner = new Scanner(System.in);
	
	public double getValorSaque() {
		System.out.print("Digite o valor do saque:");
		return scanner.nextDouble();
	}

	public double getValorDeposito() {
		System.out.print("Digite o valor do dep�sito: ");
		return scanner.nextDouble();
	}
	
	public void mostrarSaldo(double saldo) {
		System.out.println("Saldo atual: " + saldo);
	}
}

