package Controller;

import Model.Caixa_model;
import View.Caixa_view;
import java.util.Scanner;

public class Caixa_controller {

	private Caixa_model model;
	private Caixa_view view;
	
	public Caixa_controller(Caixa_model model, Caixa_view view) {
		this.model = model;
		this.view = view;
	}

	public void executar() {
		int escolha = exibirMenu();
		
		
		switch (escolha) {
		case 1:
			double valorSaque = view.getValorSaque();
			model.sacar(valorSaque);
			view.mostrarSaldo(model.getSaldo());
			break;
		case 2:
			double valorDeposito = view.getValorDeposito();
			model.depositar(valorDeposito);
			view.mostrarSaldo(model.getSaldo());
			break;
		default:
			System.out.println("Escolha inv�lida.");
		}
	}
	
	private int exibirMenu() {
		System.out.println("Escolha uma op��o:");
		System.out.println("1. Sacar");
		System.out.println("2. Depositar");
		return view.scanner.nextInt();
		
	}
}