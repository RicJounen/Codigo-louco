package Model;

public class Caixa_model {
	private double saldo;

	public Caixa_model(double saldoInicial){
		this.saldo = saldoInicial;
	}

	public double getSaldo() {
		return saldo;
	}
	
	public void sacar (double valor) {
		if (valor > 0 && valor <= saldo) {
			saldo -= valor;
		} else {
			System.out.println("Saldo insuficiente ou valor inv�lido");
		}
	}

	public void depositar(double valor) {
		if (valor > 0) {
			saldo += valor;
		} else {
			System.out.println("Valor inv�lido para dep�sito.");
		}
	}

}

