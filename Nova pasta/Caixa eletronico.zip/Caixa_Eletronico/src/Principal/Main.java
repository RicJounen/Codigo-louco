package Principal;

import Controller.Caixa_controller;
import Model.Caixa_model;
import View.Caixa_view;

public class Main {

	public static void main(String[] args) {
		Caixa_model conta = new Caixa_model(1000.0);
		Caixa_view caixaView = new Caixa_view();
		Caixa_controller caixaController = new Caixa_controller(conta, caixaView);
		
		caixaController.executar();
	}

}
